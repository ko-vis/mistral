const CACHE = "cleanday-v2";
const ASSETS = ["./", "./index.html", "./manifest.json",
  "./icons/icon-72.png","./icons/icon-96.png","./icons/icon-128.png",
  "./icons/icon-192.png","./icons/icon-256.png","./icons/icon-384.png","./icons/icon-512.png"];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  e.respondWith(caches.match(e.request, {ignoreSearch:true}).then(r => r || fetch(e.request)));
});
